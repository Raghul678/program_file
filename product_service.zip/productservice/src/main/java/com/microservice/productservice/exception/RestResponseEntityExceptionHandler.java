package com.microservice.productservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.microservice.productservice.payload.response.ErrorResponse;

@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler{

	@ExceptionHandler(ProductServiceCustomException.class)
    public ResponseEntity<ErrorResponse> handleProductServiceException(ProductServiceCustomException exception) {
        return new ResponseEntity<>(new ErrorResponse().builder()
                .errorMessage(exception.getMessage())
                .errorCode(exception.getErrorCode())
                .build(), HttpStatus.NOT_FOUND);
    }
}

// ResponseEntityExceptionHandler - add one class extending ResponseEntityExceptionHandler and annotate it with @ControllerAdvice annotation.
// ResponseEntityExceptionHandler is a convenient base class for to provide centralized exception handling across all 
// methods through @ExceptionHandler methods. 
// @ControllerAdvice is more for enabling auto-scanning and configuration

// ResponseEntity - is a class, to Manipulate the HTTP Response.

// Lombok's @Builder is a helpful mechanism for using the Builder pattern without writing boilerplate code.










