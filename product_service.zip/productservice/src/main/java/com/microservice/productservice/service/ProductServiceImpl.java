package com.microservice.productservice.service;

import org.springframework.stereotype.Service;

import com.microservice.productservice.dto.Product;
import com.microservice.productservice.exception.ProductServiceCustomException;
import com.microservice.productservice.payload.request.ProductRequest;
import com.microservice.productservice.payload.response.ProductResponse;
import com.microservice.productservice.repository.ProductRepository;
import org.springframework.beans.BeanUtils;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@RequiredArgsConstructor
@Log4j2 // write application logs
// Logs capture and persist the important data and make it available for analysis at any point in time.
// powerful method for understanding and debugging program's run-time behavior.
public class ProductServiceImpl implements ProductService{

    private final ProductRepository productRepository;
    
    @Override
    public long addProduct(ProductRequest productRequest) {
    	
        log.info("ProductServiceImpl | addProduct is called");
        //This method is used to forward the string passed as a parameter 
        //to method to all the registered output Handler objects.

        Product product
                = Product.builder() // build the object and can initialize variable without writing much code
                .productName(productRequest.getName())
                .quantity(productRequest.getQuantity())
                .price(productRequest.getPrice())
                .build();

        product = productRepository.save(product);

        log.info("ProductServiceImpl | addProduct | Product Created");
        log.info("ProductServiceImpl | addProduct | Product Id : " + product.getProductId());
        return product.getProductId();
    }
	
    
    @Override
    public ProductResponse getProductById(long productId) {

        log.info("ProductServiceImpl | getProductById is called");
        log.info("ProductServiceImpl | getProductById | Get the product for productId: {}", productId);

        Product product
                = productRepository.findById((int) productId)
                //method of java.util.Optional class in Java is used to get the value of this Optional instance if present. 
                //If there is no value present in this Optional instance, then this method throws the exception generated.
                .orElseThrow(
                        () -> new ProductServiceCustomException("Product with given Id not found","PRODUCT_NOT_FOUND"));

        // creating product response object
        ProductResponse productResponse
                = new ProductResponse();

        // BeanUtils.copyProperties(Object source, Object target)
        // Copy the property values of the given source object into the target object.
        BeanUtils.copyProperties(product, productResponse);

        // Logs a message with parameters 
        log.info("ProductServiceImpl | getProductById | productResponse :" + productResponse.toString());

        return productResponse;
    }
    
    @Override
    public void deleteProductById(long productId) {
        log.info("Product id: {}", productId);

        if (!productRepository.existsById((int) productId)) {
            log.info("Im in this loop {}", !productRepository.existsById((int) productId));
            throw new ProductServiceCustomException(
                    "Product with given with Id: " + productId + " not found:",
                    "PRODUCT_NOT_FOUND");
        }
        log.info("Deleting Product with id: {}", productId);
        productRepository.deleteById((int) productId);

    }
    
}
